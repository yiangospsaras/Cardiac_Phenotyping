close all; clear all; clc;

disp('This code will extract line scans into an excel spreadsheet');
disp('which can then be loaded into CalTrack');
disp('      ')

disp('Please select the bioformats directory');
bf_path=uigetdir('Select bioformats directory'); %  bio-format directory
addpath(bf_path);
disp('      ')

disp('Please provide line scans in .tif format')
disp('Please select the folder with the line scans')
results_folder = uigetdir('Folder with line scans');
disp('      ')

FilePattern = fullfile(results_folder,'*.tif');
fileList = dir(FilePattern);
 
for item = 1:length(fileList)
   sample_name{item} = fileList(item).name(1:end -4);
   fileList(item).sample_name = fileList(item).name(1:end-4);
end
unique_file_names = (unique(sample_name));
IMM = [];
for file=1:length(unique_file_names)
    FileName = [unique_file_names{file}, '.tif'];
    fprintf (1, '>>> Now reading :        %s\n', FileName)
    name=strcat(fileList(file).folder, '/',fileList(file).name);
    [IMM(file).name] = unique_file_names{file};
    [IMM(file).PFinalImage_c1] = single_stack_loader(name);
end

%convert to average intensity  
for FF = 1:length(IMM)
    inter = (IMM(FF).PFinalImage_c1);
    if size(inter,1) > size(inter,2);
    nu = 2;
    else
    nu = 1;
    end
    
    AVGTrace = mean(IMM(FF).PFinalImage_c1,nu) ;   
    [IMM(FF).Average_Trace] = AVGTrace;
end

%generate excel spreadsheet at the right format
FM = length(IMM);
FMnum = 4* FM;
FMnumplus1 = (1: 4:FMnum);

for FH =1:length(IMM)
    FRMT_1(:,FH) = IMM(FH).Average_Trace;
end


FRMT = zeros (length(IMM(1).Average_Trace),FMnum);
for FH =1:length(IMM)
    blc = FMnumplus1(FH);
    FRMT(:,blc) = IMM(FH).Average_Trace;
end
FRMT_TBL = horzcat(zeros (length(IMM(1).Average_Trace),1), FRMT);

ttl = string(zeros (2,size(FRMT,2)));
string(unique_file_names);
for FI =1:length(IMM)
    blc = FMnumplus1(FI);
    tl = (unique_file_names{FI});
    ttl(1,blc) = tl;
    ttl(2,blc) = "Ratio";
    ttl(2,blc+1) = "Numerator";
    ttl(2,blc+2) = "Demoninator";
    ttl(1,blc+1) = " ";
    ttl(1,blc+2) = " ";
    ttl(1,blc+3) = " ";
    ttl(2,blc+3) = " ";
end
hzc = string(zeros (2,1));
hzc(1,1) = " ";
hzc(2,1) = " ";
ttl_TBL = horzcat(hzc,ttl);
 
FTBL = vertcat(ttl_TBL,string(FRMT_TBL));
FTBL(FTBL == "0") = " ";

name = [fileList(1).folder,'/', 'CalciumData_SingleCell.xlsx' ];
writematrix(FRMT_1,name );

disp('Line scans were successfully extracted and saved in the .tif file directory');

% Save data in the prescribed .mat format
names = name;
Li = length(FTBL) - 2;
Ti = (1:Li)';
for FJ =  1:length(IMM)
data_matrix(FJ).time = (1:Li)';
data_matrix(FJ).calcium = IMM(FJ).Average_Trace;
end

% Calcium_Traces.mat 

for i = 1:length(data_matrix)
    Calcium_Traces = [];
    folder_mat = ['Calcium_Traces_',names];
    mkdir(folder_mat)
    for j = 1:size(data_matrix(i).calcium,2)
        Calcium_Traces(j).name = ['cell',num2str(j)];
        Calcium_Traces(j).data = data_matrix(i).calcium(:,j);
        save(fullfile(folder_mat,'Calcium_Traces.mat'),'Calcium_Traces')
    end
end



