function [fitresult, gof,xData, yData] = fit_tau(x, half_v)

[xData, yData] = prepareCurveData( x, half_v );

ft = fittype( 'exp2' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Lower = [-Inf -Inf -Inf 0];
opts.Upper = [Inf Inf Inf 0];

[fitresult, gof] = fit( xData, yData, ft, opts );

end
