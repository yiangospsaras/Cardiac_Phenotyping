
        for file=1:length(unique_file_names)
            FileName = [unique_file_names{file}, '.tif'];
            fprintf (1, '>>> Now reading :        %s\n', FileName)
            name=strcat(unique_file_names{file},'.tif');
            videos(file).data = single_stack_loader(name);
            videos(file).name = name;

            figure, imshow (adapthisteq(videos(file).data(:,:,1)))
            circle = 1;
            n = 1; 

            while circle == 1;
                disp ('Please draw ROI')
                Roin(n) = drawrectangle;
                ROIns = [];
                
                cont = questdlg("Draw another ROI?", 'Please select', ...
                    'Yes', 'No', 'Yes');
                switch cont
                    case 'Yes'
                        circle = 1;
                        n = n+1;

                    case 'No'
                        circle = 0;
                disp('ROIs entered')
                end
            end

% crop rois and measure mean roi intensity
%videos(file).RoiTrace = [];
Roins = Roin;
clear Roin;
for roi= 1:length (Roins) 
    for j = 1:size((videos(file).data),3);
      F = (videos(file).data);  
FF = F(:,:,j);
Thecut(roi,:) = Roins(1,roi).Position;
regions{roi,j} = imcrop(FF, Thecut(roi,:)) ;
 videos(file).RoiTrace(roi,j) = sum(sum(sum(regions{roi,j})));
 videos(file).RoiArea(roi,1) = size(regions{roi,j},1) * size(regions{roi,j},2);
%RoiTrace(roi,j) = sum(sum(sum(regions{roi,j})));
    end 
end
 %   videos(file).RoiTrace(roi,:) = RoiTrace;

 clear Roins;

        end



figure, imshow (I)
for draw = 1:size(videos(video).RoiLocation,1)
    drawrectangle('Position', (videos(draw).RoiLocation{draw,1}), 'Label', num2str(draw));

end

















