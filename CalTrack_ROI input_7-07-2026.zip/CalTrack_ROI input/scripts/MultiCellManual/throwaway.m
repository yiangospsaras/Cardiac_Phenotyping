% % measurements_table_complete = [];
% % for i=1:length(V)
% %     measurements_table = [];
% %     clearvars    Mean_Calcium_CD Mean_Calcium_CD90 Mean_Calcium_CD50 Mean_Calcium_CD10 Time_CalciumPeak...
% %         Time_CalciumRelax AVGCalcTrace DoverD0_values Baseline ...
% %         Time_to_10 Time_to_50 Time_to_90 Time_to_10Max_Relax ...
% %         Time_to_50_Relax Time_to_90_Relax mean_Calcium_magn tau ...
% %         fit_a fit_c fit_rsquare BR t0 tend Cell_id BBdistance Nperiod CD CD90 CD50 CD10 Ton...
% %         Toff  Fmax_F0 ...
% %         T10on T50on T90on T10off ...
% %         T50off T90off CaAmplitude
% %     bb = 1;
% %     for file = 1:length(V(i).single_beat)
% % 
% %         if AcquisitionFrequency>100
% %             YY = movmean(V(i).single_beat(file).mean,4);
% %         else
% %             YY = V(i).single_beat(file).mean;
% %         end
% %         if Voltage == 'y'
% %             fprintf('Voltage analysis selected. ||  ')
% %         [CalciumPeak, CTD, CTD90, CTD50, CTD10, Time_C_peak, T_C_relax, AvgCalciumTrace, DoverD0,...
% %             yAVGCalciumTrace_baseline, Time_to_90a, Time_to_50a, Time_to_10a, Time_to_10Relax,...
% %             Time_to_50Relax, Time_to_90Relax, CalciumMagnitude,CalciumTDPre,CalciumTDPost] = parametersVoltage(YY,AcquisitionFrequency);% parameters(movmean(V(i).single_beat(file).mean,5),AcquisitionFrequency);
% %         else
% % 
% %         [CalciumPeak, CTD, CTD90, CTD50, CTD10, Time_C_peak, T_C_relax, AvgCalciumTrace, DoverD0,...
% %             yAVGCalciumTrace_baseline, Time_to_90a, Time_to_50a, Time_to_10a, Time_to_10Relax,...
% %             Time_to_50Relax, Time_to_90Relax, CalciumMagnitude,CalciumTDPre,CalciumTDPost] = parameters(YY,AcquisitionFrequency);% parameters(movmean(V(i).single_beat(file).mean,5),AcquisitionFrequency);
% %         end
% %         try
% %         CD(file,1) = CTD;
% %         CD90(file,1) = CTD90;
% %         CD50(file,1) = CTD50;
% %         CD10(file,1) = CTD10;
% %         Ton (file,1) =  Time_C_peak;
% %         Toff (file,1) =  T_C_relax;   
% %         AVGCalcTrace(file).Avg = V(i).single_beat(file).mean';%AvgCalciumTrace;   
% % 
% %         Fmax_F0(file,1) = DoverD0;
% %         Baseline(file,1) = yAVGCalciumTrace_baseline;
% % 
% %         T10on(file,1) = Time_to_90a;
% %         T50on(file,1) = Time_to_50a;
% %         T90on(file,1) =Time_to_10a;
% %         T10off(file,1) = Time_to_10Relax;
% %         T50off(file,1) = Time_to_50Relax;
% %         T90off(file,1) = Time_to_90Relax; 
% % 
% %         CaAmplitude(file,1) = CalciumMagnitude;
% % 
% %         tau(file,1) = V(i).single_beat(file).tau;
% %         fit_a(file,1) = V(i).single_beat(file).a;
% %         fit_c(file,1) = V(i).single_beat(file).c;
% %         fit_rsquare(file,1) = V(i).single_beat(file).rsquare;
% % 
% %         t0(file,1) = CalciumTDPre;
% %         tend(file,1) = CalciumTDPost;
% % 
% %         BR(file,1) = V(i).single_beat(file).BR;
% %         BBdistance(file,1) = V(i).single_beat(file).BBdistance* 1000;
% %         Nperiod(file,1) = V(i).single_beat(file).Nperiod;
% % 
% %         catch
% %             disp('>>>>>> error occurred in computing the parameters. Trace saved in "error_parameters" (when an error occurs param have value 0)')
% %             Er_param(b).data = V(i).single_beat(file).mean';
% %             Er_param(b).Video_id = i;
% %             Er_param(b).Video_name = V(i).name;
% %             Er_param(b).Cell_id = file;
% %             Cell_id(bb) = file;
% %             b = b+1;
% %             bb = bb + 1; 
% %             
% %             CD(file,1) = NaN;
% %             CD90(file,1) = NaN;
% %             CD50(file,1) = NaN;
% %             CD10(file,1) = NaN;
% %             Ton (file,1) =  NaN;
% %             Toff (file,1) =  NaN;   
% %             AVGCalcTrace(file).Avg = NaN;   
% %             Fmax_F0(file,1) = NaN;
% %             Baseline(file,1) = NaN;
% %             T10on(file,1) = NaN;
% %             T50on(file,1) = NaN;
% %             T90on(file,1) =NaN;
% %             T10off(file,1) = NaN;
% %             T50off(file,1) = NaN;
% %             T90off(file,1) = NaN; 
% %             CaAmplitude(file,1) = NaN;
% %             tau(file,1) = NaN;
% %             fit_a(file,1) = NaN;
% %             fit_c(file,1) = NaN;
% %             fit_rsquare(file,1) = NaN;
% %             t0(file,1) = NaN;
% %             tend(file,1) = NaN;
% %             BR(file,1) = NaN;
% %             BBdistance(file,1) = NaN;
% %             Nperiod(file,1) = NaN;
% %             SNR(file,1) = NaN;
% %         end 
% %     end
% %     
% %     if_error_param = exist('Er_param');
% %     
% %     K = 1:length(V(i).single_beat); 
% %     Cell_n = K';
% %     Video = cell(size(Cell_n));
% %     Video(:) = {V(i).name}; 
% % 
% %     CD =  CD * 1000;
% %     CD90 = CD90 * 1000;
% %     CD50 = CD50 * 1000; 
% %     CD10 = CD10 * 1000;
% %     Ton = Ton * 1000;
% %     Toff = Toff * 1000;
% %     T90on = T90on * 1000;
% %     T50on = T50on * 1000;
% %     T10on = T10on * 1000;
% %     T10off = T10off * 1000;
% %     T50off = T50off * 1000;
% %     T90off = T90off * 1000;
% %     t0 = t0 * 1000;
% %     tend = tend * 1000;
% % 
% %     measurements_table = table(Video, Cell_n,...
% %       Baseline, Fmax_F0, CD, CD90, CD50, ...
% %       CD10, Ton, Toff, ...
% %       T10on, T50on, T90on, T10off, ...
% %       T50off, T90off, tau, fit_a, fit_c,fit_rsquare, BR, t0, tend, BBdistance, Nperiod);%, BBtime_mean,Nperiod);
% % 
% %       if exist('Cell_id') == 1
% %         measurements_table([Cell_id],:) = [];
% %       end
% %      % writetable(measurements_table, fullfile(path,'Calcium_measurements_forPlot.xlsx'),'Sheet',i );
% % 
% % 
% %     matrix = [];
% %     matrix = V(i).single_beat;
% %     SNR = [];
% %     SNRN = [];
% %     [SNR] = CalculateSNR(matrix, AcquisitionFrequency, cutoff, PacingFrequency);%
% %     SNRN = cell2mat({SNR.SignalToNoiseRatio})';
% %     Signal_to_Noise_Ratio = table(SNRN);
% % 
% %     Signal_to_Noise_Ratio.Properties.VariableNames = {'Signal_to_Noise_Ratio'};
% %     
% %     measurements_table = horzcat(measurements_table , Signal_to_Noise_Ratio);
% % 
% %     %measurements_table_complete = [measurements_table_complete ; measurements_table];
% % 
% % 
% % end
% 
% 
% 
% video_id = [];
% video_data = [];
% 
%         
% if if_error_param == 1
%     [video_id,j1,j2] = unique([Er_param.Video_id]);
%     video_names = {Er_param([j1]).Video_name}; %;
% 
%     for v = 1:length(video_id)
%         video_data = Er_param([Er_param.Video_id]==video_id(v));
%     for i=1:length(video_data)
%         leng(i) = length(video_data(i).data);
%     end
%     leng_min = min(leng);
%     leng_max = max(leng);
% 
%     Y = [];
%     for i=1:length(video_data)
%         ext = [];
%         ext = [video_data(i).data';video_data(i).data(end)*ones(leng_max-length(video_data(i).data),1)];
%         Y = [Y ext];
%     end
%   %  writematrix(Y,fullfile(path,'Calcium_Traces_error_param.xlsx'),'Sheet',video_names{1,v})
%     end
% end


for i=1:length(V)
    measurements_table = [];
    clearvars    Mean_Calcium_CD Mean_Calcium_CD90 Mean_Calcium_CD50 Mean_Calcium_CD10 Time_CalciumPeak...
        Time_CalciumRelax AVGCalcTrace DoverD0_values Baseline ...
        Time_to_10 Time_to_50 Time_to_90 Time_to_10Max_Relax ...
        Time_to_50_Relax Time_to_90_Relax mean_Calcium_magn tau ...
        fit_a fit_c fit_rsquare BR t0 tend Cell_id BBdistance Nperiod CD CD90 CD50 CD10 Ton...
        Toff  Fmax_F0 ...
        T10on T50on T90on T10off ...
        T50off T90off CaAmplitude
    bb = 1;
    for file = 1:length(V(i).single_beat)

        if AcquisitionFrequency>100
            YY = movmean(V(i).single_beat(file).mean,4);
        else
            YY = V(i).single_beat(file).mean;
        end
        if size(YY,1) <30
    CD =  0 ;
    CD90 = 0 ;
    CD50 = 0 ;
    CD10 = 0 ;
    Ton = 0 ;
    Toff = 0 ;
    T90on =0 ;
    T50on =0 ;
    T10on =0 ;
    T10off = 0 ;
    T50off =0 ;
    T90off = 0 ;
    t0 = 0 ;
    tend = 0 ;
    Baseline = 0 ;
    Fmax_F0 = 0 ;
    tau = 0 ;
    fit_a = 0 ;
    fit_c = 0 ;
    fit_rsquare = 0 ;
    BR = 0 ;
    BBdistance = 0 ;
    Nperiod = 0 ;

        else
        if Voltage == 'y'
            fprintf('Voltage analysis selected. || ')
        [CalciumPeak, CTD, CTD90, CTD50, CTD10, Time_C_peak, T_C_relax, AvgCalciumTrace, DoverD0,...
            yAVGCalciumTrace_baseline, Time_to_90a, Time_to_50a, Time_to_10a, Time_to_10Relax,...
            Time_to_50Relax, Time_to_90Relax, CalciumMagnitude,CalciumTDPre,CalciumTDPost] = parametersVoltage(YY,AcquisitionFrequency);% parameters(movmean(V(i).single_beat(file).mean,5),AcquisitionFrequency);
        else

        [CalciumPeak, CTD, CTD90, CTD50, CTD10, Time_C_peak, T_C_relax, AvgCalciumTrace, DoverD0,...
            yAVGCalciumTrace_baseline, Time_to_90a, Time_to_50a, Time_to_10a, Time_to_10Relax,...
            Time_to_50Relax, Time_to_90Relax, CalciumMagnitude,CalciumTDPre,CalciumTDPost] = parameters(YY,AcquisitionFrequency);% parameters(movmean(V(i).single_beat(file).mean,5),AcquisitionFrequency);
        end
        try
        CD(file,1) = CTD;
        CD90(file,1) = CTD90;
        CD50(file,1) = CTD50;
        CD10(file,1) = CTD10;
        Ton (file,1) =  Time_C_peak;
        Toff (file,1) =  T_C_relax;   
        AVGCalcTrace(file).Avg = V(i).single_beat(file).mean';%AvgCalciumTrace;   

        Fmax_F0(file,1) = DoverD0;
        Baseline(file,1) = yAVGCalciumTrace_baseline;

        T10on(file,1) = Time_to_90a;
        T50on(file,1) = Time_to_50a;
        T90on(file,1) =Time_to_10a;
        T10off(file,1) = Time_to_10Relax;
        T50off(file,1) = Time_to_50Relax;
        T90off(file,1) = Time_to_90Relax; 

        CaAmplitude(file,1) = CalciumMagnitude;

        t0(file,1) = CalciumTDPre;
        tend(file,1) = CalciumTDPost;

        BR(file,1) = V(i).single_beat(file).BR;
        BBdistance(file,1) = V(i).single_beat(file).BBdistance* 1000;
        Nperiod(file,1) = V(i).single_beat(file).Nperiod;

        tau(file,1) = V(i).single_beat(file).tau;
        fit_a(file,1) = V(i).single_beat(file).a;
        fit_c(file,1) = V(i).single_beat(file).c;
        fit_rsquare(file,1) = V(i).single_beat(file).rsquare;

        

        catch
            disp('>>>>>> error occurred in computing the parameters. Trace saved in "error_parameters" (when an error occurs param have value 0)')
            Er_param(b).data = V(i).single_beat(file).mean';
            Er_param(b).Video_id = i;
            Er_param(b).Video_name = V(i).name;
            Er_param(b).Cell_id = file;
            Cell_id(bb) = file;
            b = b+1;
            bb = bb + 1; 
            
            CD(file,1) = NaN;
            CD90(file,1) = NaN;
            CD50(file,1) = NaN;
            CD10(file,1) = NaN;
            Ton (file,1) =  NaN;
            Toff (file,1) =  NaN;   
            AVGCalcTrace(file).Avg = NaN;   
            Fmax_F0(file,1) = NaN;
            Baseline(file,1) = NaN;
            T10on(file,1) = NaN;
            T50on(file,1) = NaN;
            T90on(file,1) =NaN;
            T10off(file,1) = NaN;
            T50off(file,1) = NaN;
            T90off(file,1) = NaN; 
            CaAmplitude(file,1) = NaN;
            tau(file,1) = NaN;
            fit_a(file,1) = NaN;
            fit_c(file,1) = NaN;
            fit_rsquare(file,1) = NaN;
            t0(file,1) = NaN;
            tend(file,1) = NaN;
            BR(file,1) = NaN;
            BBdistance(file,1) = NaN;
            Nperiod(file,1) = NaN;
            SNR(file,1) = NaN;
        end 
       
        end
    end
    
    if_error_param = exist('Er_param');
    
    K = 1:length(V(i).single_beat); 
    Cell_n = K';
    Video = cell(size(Cell_n));
    Video(:) = {V(i).name}; 

    CD =  CD * 1000;
    CD90 = CD90 * 1000;
    CD50 = CD50 * 1000; 
    CD10 = CD10 * 1000;
    Ton = Ton * 1000;
    Toff = Toff * 1000;
    T90on = T90on * 1000;
    T50on = T50on * 1000;
    T10on = T10on * 1000;
    T10off = T10off * 1000;
    T50off = T50off * 1000;
    T90off = T90off * 1000;
    t0 = t0 * 1000;
    tend = tend * 1000;

    measurements_table = table(Video, Cell_n,...
      Baseline, Fmax_F0, CD, CD90, CD50, ...
      CD10, Ton, Toff, ...
      T10on, T50on, T90on, T10off, ...
      T50off, T90off, tau, fit_a, fit_c,fit_rsquare, BR, t0, tend, BBdistance, Nperiod);%, BBtime_mean,Nperiod);

      if exist('Cell_id') == 1
        measurements_table([Cell_id],:) = [];
      end
     % writetable(measurements_table, fullfile(path,'Calcium_measurements_forPlot.xlsx'),'Sheet',i );

    matrix = [];
    matrix = V(i).single_beat;
    SNR = [];
    SNRN = [];
    [SNR] = CalculateSNR(matrix, AcquisitionFrequency, cutoff, PacingFrequency);%
    SNRN = cell2mat({SNR.SignalToNoiseRatio})';
    Signal_to_Noise_Ratio = table(SNRN);

    Signal_to_Noise_Ratio.Properties.VariableNames = {'Signal_to_Noise_Ratio'};
    
    measurements_table = horzcat(measurements_table , Signal_to_Noise_Ratio);

    measurements_table_complete = [measurements_table_complete ; measurements_table];


end

