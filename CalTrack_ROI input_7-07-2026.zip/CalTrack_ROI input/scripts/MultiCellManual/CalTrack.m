
% CalTrack_MultiCell

script_folder = cd;
addpath(cd);

disp('Please select the movies directory');

rootPath = uigetdir(path, 'Please select the movies directory');
cd(rootPath)

mkdir calcium_analysis


minArea = 45;

minElongationParameter = 3;

mov = questdlg('Do you have .m4v files?','Please select video file format',...
    'Yes','No ', 'Yes');

switch mov
    
    case 'Yes'
    videoPaths = dir('*.m4v');

    for video = 1: length(videoPaths)

        fileName = videoPaths(video).name;
        fprintf(' >>> analyzing video:  %s \n', fileName)
        cap = [];
        cap = VideoReader(fileName); 

        h = cap.Height;
        w = cap.Width;
        n = cap.NumFrames;

        V = (zeros(h,w,n));
        vidFrame_g = [];

        for i = 1:n
            vidFrame = read(cap,i);
            vidFrame_g(:,:) = rgb2gray(vidFrame);
            tif_file = fullfile(rootPath,strcat(fileName,'_TimeLapse.tif'));
            V(:,:,i) = double(vidFrame_g)/255;
        end

        videos(video).data = V;
        
    end

    case 'No ' 

    tif = questdlg('Do you have .tif files?','Please select video file format',...
    'Yes','No ', 'Yes');

    switch tif
        case'Yes'
        disp('Please select the bio-format directory');
        bf_path=uigetdir('D:/','Select bf directory');
        addpath(bf_path);
        videoPaths = dir('*.tif*');
        case 'No '
        disp('Please select the video folder to convert to tif');
        convert_to_tif()
        videoPaths = dir('*.tif*');

    end
        for item = 1:length(videoPaths)
           sample_name{item} = videoPaths(item).name(1:end -4);
           videoPaths(item).sample_name = videoPaths(item).name(1:end-4);
        end
        
        unique_file_names = (unique(sample_name));
%% Display single frame to draw ROIs
screensize=get(groot, 'Screensize');
               for file=1:length(unique_file_names)
            FileName = [unique_file_names{file}, '.tif'];
            fprintf (1, '>>> Now reading :        %s\n', FileName)
            name=strcat(unique_file_names{file},'.tif');
            videos(file).data = single_stack_loader(name);
            videos(file).name = name;
 
            Vi = videos(file).data;
            Calcium(file).name = videos(file).name;
            Name = Calcium(file).name;
            VI(:,:) = rescale(mean(Vi,3));
            f = figure;
            f.Position = [100 100 ((screensize(3)*0.75)) ((screensize(4)*0.75))];
            annt = [  ' Please draw ROI   |   Current file: ', num2str(file), '  of  ', num2str(length(unique_file_names)) ];
            imshow (VI, 'InitialMagnification', 'fit'), title(annt);
            circle = 1;
            n = 1;          

            while circle == 1;
                disp ('Please draw ROI')
                Roin(n) = drawrectangle;
                ROIns = [];
                
                cont = questdlg("Draw another ROI?", 'Please select', ...
                    'Yes', 'No', 'Yes');
                switch cont
                    case 'Yes'
                        circle = 1;
                        n = n+1;

                    case 'No'
                        circle = 0;
                disp('ROIs entered')
                end
            end

% crop rois and measure mean roi intensity
%videos(file).RoiTrace = [];
Roins = Roin;
clear Roin;
for roi= 1:length (Roins) 
    for j = 1:size((videos(file).data),3);
      F = (videos(file).data);  
FF = F(:,:,j);
Thecut(roi,:) = Roins(1,roi).Position;
regions{roi,j} =imcrop(FF, Thecut(roi,:)) ;
 videos(file).RoiTrace(roi,j) = sum(sum(sum(regions{roi,j})));
 videos(file).RoiArea(roi,1) = size(regions{roi,j},1) * size(regions{roi,j},2);
 videos(file).RoiLocation(roi,1) = {Roins(1,roi).Position};
 %RoiTrace(roi,j) = sum(sum(sum(regions{roi,j})));
    end 
end
 %   videos(file).RoiTrace(roi,:) = RoiTrace;
 clear Roins;

               end

end
%% Display ROIs and extracted traces for user manual QC
for video = 1: length(videos)

    V = videos(video).data;
    Calcium(video).name = videos(video).name;
    Name = Calcium(video).name;
    I(:,:) = rescale(mean(V,3));

    numcol = 255/(size(videos(video).RoiLocation,1));
    R = (0:numcol:255);
    G = (0:numcol:255);
    B = (0:numcol:255);
   
    for draw = 1:size(videos(video).RoiLocation,1)
    col (draw,:) = ([rand rand rand] .*255);
    col1 = col./255;
    end
   for draw = 1:size(videos(video).RoiLocation,1)
       pos = (videos(video).RoiLocation{draw,1});
        COL =  col1 (draw,:);
       I = insertShape(I,'rectangle',pos, Linewidth = 3, Color = (COL)); 
       I = insertText(I,pos(1:2), num2str(draw),FontSize=20, BoxColor='black',BoxOpacity=0,TextColor="white" );
   end
   
      figure('Name',strcat('video',num2str(video))), clf, 
      subplot (1,2,1), imshow(I),title({'Selected ROI'}) 


   subplot (1,2,2), title('Mean Intensity for Selected ROIs')
    for PL = 1: size(videos(video).RoiLocation,1);
        ROIname(PL,:) = (sprintf( '%03d', PL));%1:size(videos(video).RoiLocation,1))) %        ROIname(PL,:) = (sprintf('  ROI %g', '%03d', PL));%1:size(videos(video).RoiLocation,1)))
        COL =  col1 (PL,:);
        plot(videos(video).RoiTrace(PL,:)', 'Color', (COL));%, 'DisplayName',name) 
        legend(ROIname,'Location','SouthOutside','Orientation','horizontal','Box','off')%, legend('boxoff');
        hold on
    end   
        hold off
        clear I
end
remove =questdlg('Would you like to remove any cell?','Filter undesired cells',...
    'Yes','No ', 'Yes');

switch remove
    case 'Yes'
    prompt = {'\bf \fontsize{12} Please enter the video number for those videos that contain the cells to be removed (from figures title): e.g. [1 2 3] (if more than one cell from the same video, than repeat the video number)',...
    '\bf \fontsize{12} Please enter the cell number for the cells to be removed (subplots title): e.g. 1 2 3 (their order needs to match the videos order and when you want to remove more than 1 cell from the same video, report the cell number from the largest to the smallest'};
    dlgtitle = 'Remove cells';
    dims = [1 120];
    definput = {'','', '', '','','','',''};
    opts.Interpreter = 'tex';
    RC = inputdlg(prompt,dlgtitle,dims,definput, opts);
    rem_vid = str2num(RC{1});
    rem_cell = str2num(RC{2});

    r = [rem_vid' rem_cell'];
      
    for i=1:length(rem_vid)
        videos(rem_vid(i)).RoiTrace(rem_cell(i),:)=[];
    end
end

j=1;
for i=1:length(videos)
    if (isempty(videos(i).RoiTrace)==1)
        id(j)=i;
        j=j+1;
    end
end

if exist('id') == 1
    Calcium(id) = [];
end


cd('calcium_analysis')
switch mov
    case 'Yes'

for i = 1:length (videos)
sz(i) = length (videos(i).RoiTrace);
end
minallowed = min(sz);

for i = 1:length (videos)
    for k = 1:size((videos(i).RoiTrace),1)
        samp = (videos(i).RoiTrace(k,:)) ;
videos(i).RT(k,:) = samp(1:minallowed);
    end
end

for i = 1:length (videos)
 mRT = mean(videos(i).RoiTrace',2);
videos(i).RT = (mRT(1:minallowed));
end

RoiTr= ((vertcat (videos.RoiTrace)'));

      for i = 1:size( videos,2);
          for j = 1:size((videos(i).RoiTrace),1)
              Roiname(j,i)= {videos(i).name};
          end
      end

isEm = cellfun(@isempty,Roiname);
RoiNM = (Roiname(~isEm));

FileName = RoiNM';%cat(1,Roiname{:});


TableTrace = string(RoiTr);

for k = 1:length(FileName)
Fnam(:,k) = string(FileName(k));
end
TraceTable = vertcat (Fnam,TableTrace );
writematrix(TraceTable,fullfile('CalciumData_MultiCell.xlsx'))


% for i=1:size(videoPaths,1)
%             Cell = videos(i).RoiTrace';
%             name = {videoPaths.name}';
%             writematrix(Cell,fullfile('CalciumData_MultiCell.xlsx'),'Sheet',videos(i).name(1:31))
%         end
 end

switch tif
    case 'Yes'

for i = 1:length (videos)
sz(i) = length (videos(i).RoiTrace);
end
minallowed = min(sz);

for i = 1:length (videos)
    for k = 1:size((videos(i).RoiTrace),1)
        samp = (videos(i).RoiTrace(k,:)) ;
videos(i).RT(k,:) = samp(1:minallowed);
    end
end

 RoiTr= ((vertcat (videos.RT)'));

      for i = 1:size( videos,2);
          for j = 1:size((videos(i).RoiTrace),1)
              Roiname(j,i)= {videos(i).name};
          end
      end
      FileName = Roiname(~cellfun('isempty', Roiname));
      TraceTable = vertcat(FileName', (num2cell(RoiTr))); 
writecell(TraceTable,fullfile('FullCalciumTraces_ROI.xlsx'))
end
warning('off')

results_folder = pwd;
disp(strcat('Done! Results saved in: ',pwd))
